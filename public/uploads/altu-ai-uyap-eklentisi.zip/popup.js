document.addEventListener('DOMContentLoaded', () => {
  const apiUrlInput = document.getElementById('apiUrl');
  const saveBtn = document.getElementById('saveBtn');
  const statusDiv = document.getElementById('status');

  chrome.storage.local.get(['apilexApiUrl'], (result) => {
    if (result.apilexApiUrl) {
      apiUrlInput.value = result.apilexApiUrl;
    }
  });

  saveBtn.addEventListener('click', () => {
    const url = apiUrlInput.value.trim().replace(/\/$/, "");
    chrome.storage.local.set({ apilexApiUrl: url }, () => {
      statusDiv.textContent = "Ayarlar başarıyla kaydedildi!";
      setTimeout(() => { statusDiv.textContent = ""; }, 2000);
    });
  });
});