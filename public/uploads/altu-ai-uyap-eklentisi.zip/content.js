console.log("[altu Ai UYAP] Eklenti aktif.");

function injectAPILexButton() {
  if (document.getElementById("altu-sync-btn")) return;

  const headers = document.querySelectorAll("h1, h2, .page-header, .title, .portlet-title");
  let target = headers[0];

  if (!target) {
    target = document.querySelector(".content-header") || document.body;
  }

  const btn = document.createElement("button");
  btn.id = "altu-sync-btn";
  btn.innerText = "⚖️ altu Ai'ye Davaları Aktar";
  btn.style.cssText = `
    padding: 8px 16px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-size: 13px;
    margin: 10px;
    box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);
    transition: all 0.2s;
    z-index: 99999;
  `;
  btn.onmouseover = () => { btn.style.background = "#1d4ed8"; };
  btn.onmouseout = () => { btn.style.background = "#2563eb"; };

  btn.onclick = async () => {
    btn.disabled = true;
    btn.innerText = "⏳ Veriler Ayrıştırılıyor...";
    
    const parsedData = parseUyapPage();
    
    if (parsedData.dosyalar.length === 0) {
      alert("Sayfada aktarılabilir dava dosyası bulunamadı. Dava listesi sayfasında olduğunuzdan emin olun.");
      btn.disabled = false;
      btn.innerText = "⚖️ altu Ai'ye Davaları Aktar";
      return;
    }

    btn.innerText = "🚀 altu Ai'ye Gönderiliyor...";

    chrome.storage.local.get(['apilexApiUrl'], async (result) => {
      const apiUrl = result.apilexApiUrl || "http://localhost:3001";
      try {
        const res = await fetch(`${apiUrl}/api/uyap`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ data: parsedData })
        });
        
        if (res.ok) {
          const resData = await res.json();
          alert(`İşlem Başarılı! UYAP portalından ${resData.aktarilan || parsedData.dosyalar.length} adet dava dosyası ve duruşma başarıyla altu Ai sisteminize aktarıldı.`);
        } else {
          alert("altu Ai sunucusu hatası. altu Ai panelinin açık olduğunu kontrol edin.");
        }
      } catch (err) {
        console.error(err);
        alert(`Bağlantı Hatası: altu Ai sunucusuna erişilemedi. API URL'sinin (${apiUrl}) doğru olduğunu doğrulayın.`);
      } finally {
        btn.disabled = false;
        btn.innerText = "⚖️ altu Ai'ye Davaları Aktar";
      }
    });
  };

  if (target === document.body) {
    btn.style.position = "fixed";
    btn.style.top = "10px";
    btn.style.right = "10px";
    document.body.appendChild(btn);
  } else {
    target.appendChild(btn);
  }
}

function parseUyapPage() {
  const dosyalar = [];
  const tables = document.querySelectorAll("table, .grid-table, .ui-datatable-data");
  
  tables.forEach(table => {
    const rows = table.querySelectorAll("tr");
    rows.forEach(row => {
      const cells = row.querySelectorAll("td");
      if (cells.length >= 3) {
        let dosyaNo = "";
        let ad = "";
        let mahkeme = "";
        let esasNo = "";
        let konu = "UYAP Otomatik Aktarımı";
        let tcKimlik = "";

        cells.forEach((cell, idx) => {
          const txt = cell.innerText.trim();
          if (/\b20\d{2}\s*\/\s*\d+\b/.test(txt)) {
            dosyaNo = txt;
            esasNo = txt.split("/")[1] || txt;
          }
          else if (txt.includes("MAHKEMESİ") || txt.includes("HAKİMLİĞİ") || txt.includes("DAİRESİ")) {
            mahkeme = txt;
          }
          else if (idx === 1 || idx === 2) {
            if (txt.length > 5 && txt.length < 50) {
              ad = txt;
            }
          }
        });

        if (dosyaNo) {
          if (!ad) ad = "UYAP DAVASI";
          if (!mahkeme) mahkeme = "UYAP Portal Mahkemesi";
          
          dosyalar.push({
            dosyaNo,
            ad: ad.toUpperCase(),
            konu,
            mahkeme,
            esasNo,
            tcKimlik: tcKimlik || `TC-${Math.floor(100000 + Math.random() * 900000)}`,
            durusmalar: []
          });
        }
      }
    });
  });

  return { dosyalar };
}

setInterval(injectAPILexButton, 2000);